import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReviewComponent } from "src/review/review.component";
import { ResultComponent } from "src/result/result.component";
import { RegistrationComponent } from "src/registration/registration.component";
import { QuizComponent } from "src/quiz/quiz.component";


const routes: Routes = [
  {path:'review', component:ReviewComponent},
  {path:'result',component:ResultComponent},
  {path:'registration',component:RegistrationComponent},
  {path:'quiz',component:QuizComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
