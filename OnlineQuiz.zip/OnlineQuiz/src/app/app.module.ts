import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ResultComponent } from "../result/result.component";


import { HttpClientModule } from "@angular/common/http";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { QuizComponent } from "src/quiz/quiz.component";
import { ReviewComponent } from "src/review/review.component";
import { RegistrationComponent } from "src/registration/registration.component";

@NgModule({
  declarations: [
    AppComponent,ResultComponent,QuizComponent,ReviewComponent,RegistrationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,HttpClientModule,FormsModule,ReactiveFormsModule 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
