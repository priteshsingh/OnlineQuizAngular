import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";

@Injectable({
    providedIn:'root'
})
export class DataService {

    private content = new BehaviorSubject('');
    share$ = this.content.asObservable();

    private totalQuestion = new BehaviorSubject(''+0);
    question = this.totalQuestion.asObservable();

    private totalAnswer = new BehaviorSubject(''+0);
    answer = this.totalAnswer.asObservable();

    private review = new BehaviorSubject([]);
    rev = this.review.asObservable();

    sendReview(review ) {
        this.review.next(review);
    }

    sendMessage(message:string){
        this.content.next(message)
    }

    sendQuestionAns(answer,question){
        this.totalAnswer.next(answer);
        this.totalQuestion.next(question);
    }

}