
import { Component} from '@angular/core';
import { Router } from "@angular/router";
import { NgModule } from '@angular/core';
import { Registration } from "src/registration/registration";
import { DataService } from "src/app/data.service";

@Component({
  selector: 'registration',
  templateUrl:'./registration.component.html'
  //styleUrls: ['./book.component.css']
})

export class RegistrationComponent {

registration = new Registration();
  constructor(private router:Router , private dataService:DataService){}

  submitRegistration(){
    console.log("submity");
    this.dataService.sendMessage(this.registration.firstName);
    
    this.router.navigate(['/quiz']);
  }
}