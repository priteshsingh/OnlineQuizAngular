export class Registration {
    constructor(
            public firstName:string = '',
            public email:string = '',
    ){}
}