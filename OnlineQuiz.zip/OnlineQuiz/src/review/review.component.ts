
import { Component, OnInit } from '@angular/core';
import { DataService } from "src/app/data.service";
import { QuizService } from "src/quiz/quiz.service";

@Component({
  selector: 'review',
  templateUrl:'./review.component.html'

})

export class ReviewComponent implements OnInit {
  quiz: any;
  review :any;
  data: {
  };
  constructor(private dataService:DataService, private quizService:QuizService){}

  ngOnInit(): void {
    this.dataService.rev.subscribe (
       message=>{this.data=message
         console.log(this.data);
         console.log("message--"+message);
       
      
      }
    )
    this.quizService.getQuestion().subscribe (
      data => this.quiz = data
    )

  }

}