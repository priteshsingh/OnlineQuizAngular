import { Component, OnInit, Input } from '@angular/core';
import { QuizService } from "src/quiz/quiz.service";
import{NgForm} from '@angular/forms';
import { DataService } from "src/app/data.service";
import { Router } from "@angular/router";

@Component({
  selector: 'qui-z',
  templateUrl:'./quiz.component.html'
})

export class QuizComponent implements OnInit {
  review1: any;
  questions: any;
  correctAnswer: any;
  selected: any;
  totalAnswer: number;
  rightAnswer: number;
  data: string;
   quiz:any

   review:any
  constructor(private service:QuizService,private dataService:DataService,private router:Router){}

  ngOnInit(): void {
   this.service.getQuestion().subscribe(
     data => {this.quiz=data}
   )

  this.dataService.share$.subscribe(
  message =>{this.data=message;}
  )}

  showResult(){
  
  }

  submitTest(form:NgForm){
    console.log("form data here" +JSON.stringify(form.value)); 
          this.review=form.value;
      this.review1 = Object.keys(this.review).map(x => this.review[x])
       console.log(this.review1 + "rew---------")
    this.rightAnswer = 0;
    this.totalAnswer = 0;
    this.selected = form.value;
    this.correctAnswer = form.value;

    this.service.getQuestion().subscribe(
      data => {
        this.questions = data;
        for(let i = 0, j = 1; i<this.questions.length;i++,j++) {
          console.log("answers: "+this.questions[i].answer);
          console.log("selected: "+this.selected[j]);
    

        if(this.selected[j] in this.questions[i] && (this.selected[j]!=null)) {
          this.totalAnswer++;
          if(this.selected[j] == this.questions[i]["answer"]) {
            this.rightAnswer++;
          }
        }
        
  
      }
      console.log("right answer"+ this.rightAnswer)
      console.log("total ans"+this.totalAnswer)
      
      this.dataService.sendQuestionAns(this.rightAnswer,this.totalAnswer)

     
      this.dataService.sendReview(this.review1);

      
    }
    
    );
  // console.log(this.rightAnswer)
  // console.log(this.totalAnswer)
    
      this.router.navigate(['/result']);
  }
}