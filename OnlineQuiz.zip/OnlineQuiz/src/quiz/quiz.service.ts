
import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

 @Injectable({
    providedIn:'root'
 })
export class QuizService {
    url="../assets/data/questions.json"
    constructor(private http:HttpClient){}

    getQuestion(){
        return this.http.get(this.url);
    }
}