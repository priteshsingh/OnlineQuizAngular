
import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router/router";
import { QuizComponent } from "src/quiz/quiz.component";
import { DataService } from "src/app/data.service";

@Component({
  
  templateUrl:'./result.component.html'
  //styleUrls: ['./book.component.css']
})

export class ResultComponent implements OnInit {
  data: string;

  constructor(private service:DataService){}

  ngOnInit(): void {
    this.service.answer.subscribe(
      data =>{ this.data = data
        console.log(this.data +"data service");
      }   
    )
    
  }
  
}